#
# TABLE STRUCTURE FOR: ci_user_groups
#

DROP TABLE IF EXISTS `ci_user_groups`;

CREATE TABLE `ci_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (2, 'customer');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (4, 'accountant');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (7, 'sales manager');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (8, 'programmer');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (12, 'rtgfth');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (13, 'Members');


#
# TABLE STRUCTURE FOR: ci_users
#

DROP TABLE IF EXISTS `ci_users`;

CREATE TABLE `ci_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` mediumtext NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `is_verify` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `token` varchar(255) NOT NULL,
  `password_reset_code` varchar(255) NOT NULL,
  `last_ip` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (3, 'admin', 'admin', 'admin', 'admin@admin.com', '', '$2y$10$YFRA1t5txkA9DZu4RDOOsOpjkS36tXkERzMCIIgOdmHNXezjRvrYm', '', 1, 1, 1, 1, '', '5527eaab87a00dbe1614481ef174f285', '', '2017-09-29 10:09:44', '2018-04-19 09:04:51');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (37, 'irfan90', 'irfan', 'majeed', 'irfan.majeed90@gmail.com', '123456', '$2y$10$YYsrNfWjrNVxk14/G.jLruLF8BA5EqdgP0TYSvjsDTc76nulWu3Z6', '', 7, 1, 0, 0, '', '', '', '2018-04-19 09:04:31', '2018-04-19 09:04:31');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (36, 'ali', 'ali', 'raza', 'ali@gmail.com', '123456', '$2y$10$y2NEydEkaJjjPmXLWLhr2uk090RRxpK4MihyzxwJPzT/BR4dbaSLy', '', 2, 1, 0, 0, '', '', '', '2018-04-19 09:04:39', '2018-04-19 09:04:39');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (35, 'nauman', 'nauman', 'ahmed', 'naumanahmedcs@gmail.com', '44876666655', '$2y$10$Vs8oLdjx0S8guZOKgT02PuTYD8fZoG/QVEGKQkjmmlpNLJvcvcDqK', '', 1, 1, 1, 0, 'a86c450b76fb8c371afead6410d55534', '', '', '2018-04-18 09:04:18', '2019-02-11 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (41, '部门列表', '部门列表', 'user', 'user@user.com', '', '$2y$10$vVKdrF8w4bdauyE6Rf2VEe/Ye07trKd8Q7xCqklRD4NzcpGZhrOWK', 'Kachari Road Gujrat', 2, 1, 1, 0, '', '', '', '2019-01-29 08:01:37', '2019-02-01 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (46, '部署リスト', 'code', 'glamour', 'codeglamour1@gmail.com', '', '$2y$10$MXsN1rKW5K3LktxPl3Cde.bh.M7juzuBNgvxN9uOntutHlrTszq7.', '', 1, 1, 1, 0, '', '', '', '2019-01-29 00:00:00', '2019-02-01 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (39, 'nomi', 'Muhammad', 'Noman', 'mnomannaveed007@gmail.com', '1234565844', '$2y$10$ZiCesxd56bw/oUtVK7aub.zezK37GOo92DS8F.EHck5UujUY5ngPa', '', 1, 1, 1, 0, '', '', '', '2018-04-21 05:04:52', '2019-01-29 08:01:08');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (42, 'Tahir', 'Tahir', 'Nawaz', 'm.jam.tahir@gmail.com', '', '$2y$10$ITDCCAGHwLWCfpO/D1siLulgI4fKsewHoUp/6SFBZh9zovPoCbu02', '', 1, 1, 1, 0, '', '', '', '2019-01-29 00:00:00', '2019-01-29 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (43, 'Dharmasingh', 'Dharmasingh', 'Singaram', 'dharmasingh@kenwaves.com', '', '$2y$10$HLPp/z/.uMJYEZkxZa.4ieuKRn08./akHRPZ3CixIKlf.XHi4d6r6', '', 1, 1, 1, 0, '185e65bc40581880c4f2c82958de8cfe', '', '', '2019-01-29 00:00:00', '2019-01-29 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (45, 'wwe', 'wwe', 'wwe', 'wwe@gmail.com', '', '$2y$10$bMBKgYJFVs2D9N0U1SbwaeSVFkNo0/BJnXX6a4Uy0IoaJ1/3buBJq', '', 1, 1, 0, 0, 'eb6fdc36b281b7d5eabf33396c2683a2', '', '', '2019-01-29 00:00:00', '2019-01-29 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (47, 'ssss', 'Gayathri', 'ssss', 'habana@cuba.com', '1234567890', '$2y$10$KKv9oxNN2SVkRw.xBtYsLuRaSioDvOfo7isqCKpF9xIXi.Q4w8UEq', 'hfhfghgfj', 2, 1, 1, 0, '', '', '', '2019-02-01 00:00:00', '2019-02-03 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (48, 'fdgfd', 'fdgfd', 'fdgfdg', 'jkhsdfhdsjk@gmail.com', 'fdgfdgfd', '$2y$10$kdVGCK/1bEUii2G2.qofIu336OGGRoom96lsZZMIphsVEK/8clkIu', 'fdgfdg', 8, 1, 1, 0, '', '', '', '2019-02-04 00:00:00', '2019-02-05 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (49, 'superadmin', 'ttt', 'tt', 'ttttt@yahoo.com', '9999999999', '$2y$10$qTeZyNm1u5OM9IZ0ZkIN6.DuZr9xMs6aEhcpNCKUb3gxZyvsQGfXq', 'gttt', 1, 1, 1, 0, '', '', '', '2019-02-04 00:00:00', '2019-02-04 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (50, 'vijesh', 'kp', 'bhaskar', 'vijesh721@gmail.com', '', '$2y$10$Wxv8AZigELJCwX3EOEUHIOyeIU77s.R/vLCzfyyRn8TId10DOshuq', '', 1, 1, 1, 0, '58a2fc6ed39fd083f55d4182bf88826d', '', '', '2019-02-05 00:00:00', '2019-02-10 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (51, 'harshada', 'harshada', 'joshi', 'harshada.baviskar9@gmail.com', '', '$2y$10$IaAl4IX0SkzhXuHTcPERsui.1uNPNVn.xj4sxgxN/r3x9lVExnQxG', '', 2, 1, 1, 0, '59b90e1005a220e2ebc542eb9d950b1e', '', '', '2019-02-11 00:00:00', '2019-02-13 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (52, 'rajni', 'rajni', 'joshi', 'gh@yh.com', '', '$2y$10$lp26k4BuXzcpC0BJ/F6s1uRGVm1pO9zT9kF3zbnmL1rlZR9upjtaK', '', 1, 1, 0, 0, '502e4a16930e414107ee22b6198c578f', '', '', '2019-02-11 00:00:00', '2019-02-11 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (53, 'BRUNOUSER', 'Mike', 'Otharan', 'suporte@guiacorretors.com.br', '', '$2y$10$Yx5hd7tUjvhVGqjVABeouufi9U9iEXSJc0Qjfb6k5NbVF/DMmxvUm', '', 1, 0, 1, 0, '', '0dc23b6a0e4abc39904388dd3ffadcd1', '', '2019-02-12 00:00:00', '2019-02-13 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (54, 'darkbcx', 'Daniel', 'Kore', 'darkbcx@gmail.com', '', '$2y$10$m.AFgvmZgTp4mFp0Yf3gs.PRPxqwgrSrK.1xp9J6rwzMTebM1SyDO', '', 1, 1, 1, 0, '', '', '', '2019-02-14 00:00:00', '2019-02-15 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (55, 'arway', 'ale', 'ssandro', 'alex@qnet.it', '', '$2y$10$qFmPbLeqziAr1qwxdYQHYO9scbPPIaPUl0LcqfYBdjwP6Dozh5Fwq', '', 1, 1, 1, 0, '', '', '', '2019-02-14 00:00:00', '2019-02-14 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (56, 'mahamuduld', 'Mahamudul', 'Hasan', 'mahamudulbbapi@gmail.com', '', '$2y$10$agJkQNmYBr2GpEzWKJXXp.ulgcy0x1ZPMxEbcrbPcSqJJoXlvTExS', '', 7, 0, 1, 0, '', '', '', '2019-02-16 00:00:00', '2019-02-20 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (57, 'sapto', 'milis', 'prabowo', 'sapto.milis2@gmail.com', '', '$2y$10$yBA1mQXrlph9z4uCXGreP.AWrhfVp1l2dI44Ee17TcFd3BMe4DUya', '', 8, 0, 1, 0, 'bf8229696f7a3bb4700cfddef19fa23f', '', '', '2019-02-20 00:00:00', '2019-02-25 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (58, 'galbert', 'George', 'Albert', 'geoalbert93@gmail.com', '', '$2y$10$BiDgPyBB30qSWuSoT07E8uVP8t7Ma/RMipGrOED6pOJcuhixzddK6', '', 4, 1, 1, 0, '3621f1454cacf995530ea53652ddf8fb', '', '', '2019-02-21 00:00:00', '2019-02-25 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (59, 'd', 'sd', 'sd', 'akash@auton.io', '', '$2y$10$ERO0d2nre74BoIHTnSYeoewQa.Yyn29qcu7mXGWGWQdW.QMjuiFQ.', '', 1, 1, 0, 0, '40008b9a5380fcacce3976bf7c08af5b', '', '', '2019-02-26 00:00:00', '2019-02-26 00:00:00');


