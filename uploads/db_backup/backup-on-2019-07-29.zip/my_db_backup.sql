#
# TABLE STRUCTURE FOR: ci_user_groups
#

DROP TABLE IF EXISTS `ci_user_groups`;

CREATE TABLE `ci_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (17, 'Prueba Isaac');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (8, 'programmer');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (11, 'Teacher');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (12, 'ALETA');
INSERT INTO `ci_user_groups` (`id`, `group_name`) VALUES (14, 'test');


#
# TABLE STRUCTURE FOR: ci_users
#

DROP TABLE IF EXISTS `ci_users`;

CREATE TABLE `ci_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile_no` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` mediumtext NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(4) NOT NULL DEFAULT '1',
  `is_verify` tinyint(4) NOT NULL DEFAULT '0',
  `is_admin` tinyint(4) NOT NULL DEFAULT '0',
  `token` varchar(255) NOT NULL,
  `password_reset_code` varchar(255) NOT NULL,
  `last_ip` varchar(30) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (3, 'admin', 'admin', 'admin', 'admin@admin.com', '1145666466', '$2y$10$YFRA1t5txkA9DZu4RDOOsOpjkS36tXkERzMCIIgOdmHNXezjRvrYm', '', 1, 1, 1, 1, '', '285e19f20beded7d215102b49d5c09a0', '', '2017-09-29 10:09:44', '2018-04-19 09:04:51');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (37, 'irfan90', 'irfan', 'majeed', 'irfan.majeed90@gmail.com', '123456', '$2y$10$YYsrNfWjrNVxk14/G.jLruLF8BA5EqdgP0TYSvjsDTc76nulWu3Z6', '', 7, 1, 0, 0, '', '', '', '2018-04-19 09:04:31', '2018-04-19 09:04:31');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (36, 'ali', 'ali', 'raza', 'ali@gmail.com', '123456', '$2y$10$y2NEydEkaJjjPmXLWLhr2uk090RRxpK4MihyzxwJPzT/BR4dbaSLy', '', 2, 1, 1, 0, '', '', '', '2018-04-19 09:04:39', '2019-06-13 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (35, 'nauman', 'nauman', 'ahmed', 'naumanahmedcs@gmail.com', '44876666655', '$2y$10$Vs8oLdjx0S8guZOKgT02PuTYD8fZoG/QVEGKQkjmmlpNLJvcvcDqK', '', 1, 0, 0, 0, 'a86c450b76fb8c371afead6410d55534', '', '', '2018-04-18 09:04:18', '2018-04-19 08:04:34');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (41, 'user', 'user', 'user', 'user@user.com', '89874565455', '$2y$10$vVKdrF8w4bdauyE6Rf2VEe/Ye07trKd8Q7xCqklRD4NzcpGZhrOWK', 'Kachari Road Gujrat', 8, 0, 1, 0, '', '', '', '2019-01-29 08:01:37', '2019-06-25 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (38, 'naumanit', 'nauman', 'ahmed', 'codeglamour1@gmail.com', '', '$2y$10$F82UAQYcq/yKvWqasv.HIeb5qapbDBFz/ayO/1qRRqrrzB.BASv8O', '', 1, 0, 1, 0, '', '', '', '2018-04-20 07:04:23', '2018-04-20 07:04:55');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (39, 'nomi', 'Muhammad', 'Noman', 'mnomannaveed007@gmail.com', '1234565844', '$2y$10$ZiCesxd56bw/oUtVK7aub.zezK37GOo92DS8F.EHck5UujUY5ngPa', '', 1, 1, 1, 0, '', '', '', '2018-04-21 05:04:52', '2019-01-29 08:01:08');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (42, 'aayushidixit23@gmail.com', 'Aayushi', 'Dixit', 'aayushidixit23@gmail.com', '', '$2y$10$Rx.XW5CsJHyOmu.zEkdd9.KIDbIQqmabbdypWxUbipx8ga3BUVGJi', '', 1, 1, 1, 0, '', '', '', '2019-06-11 00:00:00', '2019-06-11 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (43, 'korobosta', 'kevin', 'ongulu', 'kevinkorobosta@gmail.com', '', '$2y$10$3kjJ.yGsxvV.8mOpIH8FCOO449mMztRzghrSJIodF.lEmWgM5wFzu', '', 1, 1, 1, 0, '', '', '', '2019-06-12 00:00:00', '2019-06-17 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (44, 'dpn', 'debi', 'nayak', 'dpnayak@live.com', '', '$2y$10$OqY0daF3lYXyxphmqrD48OXd7wRvO/ki84PjHizEom7kK38q3RGdq', '', 1, 1, 1, 0, '', '', '', '2019-06-14 00:00:00', '2019-06-17 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (45, 'abc', 'abc', 'xyz', 'abc@gmail.com', '', '$2y$10$zO8fMTpO8rxFLHjaF5Ik/Oe80R19xinhtfUgm3Ly69Cgd7o55Yx6q', '', 1, 1, 0, 0, '4e0928de075538c593fbdabb0c5ef2c3', '', '', '2019-06-17 00:00:00', '2019-06-17 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (46, 'teste', 'teste', 'teste', 'teste@teste.com', 'teste', '$2y$10$Rf1qLuhhb6o7NkgKDaAGOuyOVMaDFieYeY9Kt9gcH/uUoV8s35drq', 'teste', 1, 1, 1, 0, '', '', '', '2019-06-17 00:00:00', '2019-06-17 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (47, 'yannick13', 'omoko', 'yannick', 'oambiana@gmail.com', '', '$2y$10$2LiMYXCAFCCvzuLNrmdpKOzS7MqtqSS9QHMNzIYlezNn7ka31olia', '', 1, 1, 1, 0, '', '', '', '2019-06-21 00:00:00', '2019-06-24 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (48, 'amn', 'nma', 'ert', 'asde@admin.com', '', '$2y$10$2k0xbrWCxnKdYWGtp5Y88upNYcGp/3jyxhn.CpzOyRvl5xrT57bP.', '', 8, 1, 1, 0, '33e8075e9970de0cfea955afd4644bb2', '', '', '2019-06-26 00:00:00', '2019-06-30 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (49, 'includebar@gmail.com', 'bung', 'bung', 'includebar@gmail.com', '', '$2y$10$TFEtODuOFUDURuRpqZb/legC3TWwju3uu/uCmro9PHSQjTSqHQq6K', '', 1, 1, 1, 0, '', '', '', '2019-06-26 00:00:00', '2019-06-26 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (50, 'Raka', 'zai', 'siis', 'rakajhai@gmail.com', '', '$2y$10$q1LHsPfVxaDsSfGTRSkUeumvCK/At6AE8xw8RKgkpRvsRugpGeH.W', '', 1, 1, 1, 0, '', '', '', '2019-06-26 00:00:00', '2019-07-12 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (51, 'Democratic', 'Try', 'Kiyrr', 'acb@ymail.com', '877666666', '$2y$10$aMJjyzcDhKByrEnd6FvtuOjmCUycCrlmwBgHusdxL4kMfCYPpt7ra', 'JJJJJ', 1, 1, 1, 0, '', '', '', '2019-06-27 00:00:00', '2019-07-01 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (52, 'Ustry', 'Try', 'Again', 'Ustry@gmail.com', '11111', '$2y$10$QCEAGbwxu2fYRZWU4CA31uqUyxVzgXuVAa29VIWJv57W5peVyoPP2', 'Street', 1, 0, 1, 0, '', '', '', '2019-07-04 00:00:00', '2019-07-04 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (53, 'mahsod.ik@gmail.com', 'ismail', 'khan', 'mahsod.ik@gmail.com', '3425456498', '$2y$10$lSpv4XFxr5xtknI3vzvxOeFFXngb6RrIUTCUwaxU5ewVLau71yFPe', 'street no 4,house 511,model town humak zimni islamabad', 7, 1, 1, 0, '', '', '', '2019-07-05 00:00:00', '2019-07-05 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (54, 'refli', 'refli', 'HILL', 'reflizal12@gmail.com', '', '$2y$10$NTE7uuKZxtiasKvYYb0uu.ylELGBHqxx.cD1CmO4IgsBSPflGJwPa', '', 1, 1, 1, 0, '98d6f58ab0dafbb86b083a001561bb34', '', '', '2019-07-09 00:00:00', '2019-07-12 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (55, 'Test', 'Test', 'Test', 'test@gmail.com', '091991', '$2y$10$QmsY7DMfCfF4MLY8guiIM.K12TuWCu6/4LQ7t7CEvkAfJ0nz/E52a', 'Jalan', 4, 1, 1, 0, '', '', '', '2019-07-10 00:00:00', '2019-07-11 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (56, 'qodhob', 'faarax', 'abdullahi', 'qodhobfx@gmail.com', '', '$2y$10$igk/MyHZrTMmFX2nz3/haeZOVSzvIP1MKKF1rGlDWZ3pBiVDdbDQ.', '', 1, 1, 1, 0, '', '', '', '2019-07-10 00:00:00', '2019-07-10 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (57, 'jokowi', 'Joko', 'Widodo', 'jokowi@gmail.com', '4543543', '$2y$10$J/kc3QikIdC.h1b58G50iOJVCXTDWxB/c/2Kg4c3j7/qRmos5eFeG', '', 1, 0, 1, 0, '', '', '', '2019-07-11 00:00:00', '2019-07-11 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (58, 'rest', 'test', 'test', 'mailme_rbm@rediffmail.com', '', '$2y$10$GNwHL7y5/6H/AKG6KRrSM.Hc.zpg3CJTfJdi03cwyn47xgzXOib.e', '', 16, 1, 1, 0, '', '', '', '2019-07-12 00:00:00', '2019-07-16 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (59, 'vijetha', 'vijetha', 'Acharya', 'vijeth@gmail.com', '', '$2y$10$f3P7D/UVg9jyCqfNA/Vl6OHV88/rbdMfn9TegldP8vZGiz5KKO2NG', '', 1, 1, 0, 0, 'eba0dc302bcd9a273f8bbb72be3a687b', '', '', '2019-07-16 00:00:00', '2019-07-16 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (60, 'navya', 'navya', 'ruthu', 'vijethacharyap507@gmail.com', '', '$2y$10$a2HTEfyiCucStLvifXiCEeMC3TqKSGCZP8.3EnH9OpZeZgGEOmE86', '', 1, 1, 1, 0, '', '', '', '2019-07-16 00:00:00', '2019-07-16 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (61, 'Sattu', 'satyendra', 'singh', 'pratapsinghs442@gmail.com', '', '$2y$10$.ILr2VRtrKBqkJN7gr0yLeDXAyknf/EmYC2Ux7U3fDNXYIw.6cq7W', '', 11, 1, 1, 0, '', '', '', '2019-07-17 00:00:00', '2019-07-19 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (62, 'chrisyrm11', 'Tabita', 'Krisma', 'tabteb11@gmail.com', '', '$2y$10$OKEXtyexMj1c39Dq7NiupulnfTkZUJf5Ax/EfGmcbkT7Vsoyoo9KC', '', 14, 0, 1, 0, 'fc49306d97602c8ed1be1dfbf0835ead', '', '', '2019-07-19 00:00:00', '2019-07-20 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (63, 'Shilpa', 'Shilpa', 'A', 'shilpa@theorax-dynamics.com', '', '$2y$10$OfEMbnFsDsf8OHIYjf0/CeP9vHwiw.35H9Ei009Xaen6sGySak1Qe', '', 8, 1, 1, 0, '', '', '', '2019-07-22 00:00:00', '2019-07-22 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (64, 'asep', 'suwardi', 'suwardi', 'asepsuwardi13@gmail.com', '', '$2y$10$3h.rFP43w07ZZOLEpftYgebjqxkRPWE0RGjBcoxfs1BjAUqTN7MLm', '', 1, 1, 0, 0, '9a1158154dfa42caddbd0694a4e9bdc8', '', '', '2019-07-22 00:00:00', '2019-07-22 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (65, 'admin123', 'admin', 'admin', 'admin@gmail.com', '', '$2y$10$wljfB4sNH17cq0I8kNbW.ezaOVOuj.VOrX5POgRcBl74i3l012vC6', '', 8, 0, 1, 0, 'eaae339c4d89fc102edd9dbdb6a28915', '', '', '2019-07-23 00:00:00', '2019-07-28 00:00:00');
INSERT INTO `ci_users` (`id`, `username`, `firstname`, `lastname`, `email`, `mobile_no`, `password`, `address`, `role`, `is_active`, `is_verify`, `is_admin`, `token`, `password_reset_code`, `last_ip`, `created_at`, `updated_at`) VALUES (66, 'Amiya', 'Ranjan', 'Sethi', 'amiyaranjansethi0551@gmail.com', '', '$2y$10$1WG2uMvP73GoQrJWhs8SK..IZ/0lbojY2i8rSqHNryxQVNivJxFyS', '', 1, 1, 1, 0, '', '', '', '2019-07-27 00:00:00', '2019-07-27 00:00:00');


